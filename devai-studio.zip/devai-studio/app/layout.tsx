import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'DevAI Studio — AI Website & App Builder', description: 'منصة تطوير المواقع والتطبيقات بمساعدة الذكاء الاصطناعي' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="ar" dir="rtl"><body>{children}</body></html>; }
